package cp213;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.math.BigDecimal;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 * The GUI for the Order class.
 *
 * @author Jacob Choy
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2024-10-15
 */
@SuppressWarnings("serial")
public class OrderPanel extends JPanel {

    /**
     * Implements an ActionListener for the 'Print' button. Prints the current
     * contents of the Order to a system printer or PDF.
     */
    private class PrintListener implements ActionListener {

	@Override
	public void actionPerformed(final ActionEvent e) {
	    BigDecimal taxes = OrderPanel.this.order.getTaxes();
	    BigDecimal total = OrderPanel.this.order.getTotal();
	    BigDecimal subtotal = OrderPanel.this.order.getSubTotal();

	    System.out.println("Printing order...");
	    System.out.println("Subtotal: " + subtotal);
	    System.out.println("Taxes: " + taxes);
	    System.out.println("Total: " + total);

	    try {
		PrinterJob job = PrinterJob.getPrinterJob();
		job.setPrintable(order);

		if (job.printDialog()) {
		    job.print();
		}
	    } catch (PrinterException ex) {
		ex.printStackTrace();
	    }
	}
    }

    /**
     * Implements a FocusListener on a JTextField. Accepts only positive integers,
     * all other values are reset to 0. Adds a new MenuItem to the Order with the
     * new quantity, updates an existing MenuItem in the Order with the new
     * quantity, or removes the MenuItem from the Order if the resulting quantity is
     * 0.
     */
    private class QuantityListener implements FocusListener {
	@Override
	public void focusGained(final FocusEvent evt) {
	    final JTextField source = (JTextField) evt.getSource();
	    source.selectAll();
	}

	@Override
	public void focusLost(final FocusEvent evt) {
	    final JTextField source = (JTextField) evt.getSource();
	    int index = 0;
	    for (JTextField textbox : OrderPanel.this.quantityFields) {
		if (textbox == source) {
		    break;
		} else {
		    index += 1;
		}
	    }
	    String newquantity = source.getText();

	    int newValue = 0;
	    if (newquantity.isEmpty()) {
		newValue = 0;
	    } else {
		try {
		    newValue = Integer.valueOf(newquantity);
		} catch (NumberFormatException e) {
		    newValue = 0;
		    source.setText("");
		}
	    }
	    order.update(menu.getItem(index), newValue);
	    OrderPanel.this.subtotalLabel.setText(String.format("$%6.2f", order.getSubTotal()));
	    OrderPanel.this.totalLabel.setText(String.format("$%6.2f", order.getTotal()));
	    OrderPanel.this.taxLabel.setText(String.format("$%6.2f", order.getTaxes()));
	}
    }

    // Attributes
    private Menu menu = null;
    private final Order order = new Order();
    private final DecimalFormat priceFormat = new DecimalFormat("$##0.00");
    private final JButton printButton = new JButton("Print");
    private final JLabel subtotalLabel = new JLabel("0");
    private final JLabel taxLabel = new JLabel("0");
    private final JLabel totalLabel = new JLabel("0");

    private JLabel nameLabels[] = null;
    private JLabel priceLabels[] = null;
    // TextFields for menu item quantities.
    private JTextField quantityFields[] = null;

    /**
     * Displays the menu in a GUI.
     *
     * @param menu The menu to display.
     */
    public OrderPanel(final Menu menu) {
	this.menu = menu;
	this.nameLabels = new JLabel[this.menu.size()];
	this.priceLabels = new JLabel[this.menu.size()];
	this.quantityFields = new JTextField[this.menu.size()];
	this.layoutView();
	this.registerListeners();
    }

    /**
     * Uses the GridLayout to place the labels and buttons.
     */
    private void layoutView() {
	this.setLayout(new java.awt.GridBagLayout());
	java.awt.GridBagConstraints gbc = new java.awt.GridBagConstraints();
	gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
	gbc.insets = new java.awt.Insets(5, 5, 5, 5);

	this.setBackground(new java.awt.Color(220,85,165));
	java.awt.Font headerFont = new java.awt.Font("Arial", java.awt.Font.BOLD, 16);

	gbc.gridx = 0;
	gbc.gridy = 0;
	this.add(new JLabel("Item"), gbc);
	gbc.gridx = 1;
	this.add(new JLabel("Price"), gbc);
	gbc.gridx = 2;
	this.add(new JLabel("Quantity"), gbc);

	for (int i = 0; i < this.menu.size(); i++) {
	    MenuItem item = this.menu.getItem(i);

	    gbc.gridy = i + 1;
	    gbc.gridx = 0;
	    this.nameLabels[i] = new JLabel(item.getListing());
	    this.add(this.nameLabels[i], gbc);

	    gbc.gridx = 1;
	    this.priceLabels[i] = new JLabel(priceFormat.format(item.getPrice()));
	    this.add(this.priceLabels[i], gbc);

	    gbc.gridx = 2;
	    this.quantityFields[i] = new JTextField("0");
	    gbc.fill = java.awt.GridBagConstraints.NONE;
	    gbc.ipadx = 50;
	    this.add(this.quantityFields[i], gbc);
	    gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
	}

	gbc.gridx = 0;
	gbc.gridy = this.menu.size() + 1;
	this.add(new JLabel("Subtotal:"), gbc);
	gbc.gridx = 2;
	this.add(this.subtotalLabel, gbc);

	gbc.gridx = 2;
	this.add(new JLabel(""), gbc);

	gbc.gridx = 0;
	gbc.gridy = this.menu.size() + 2;
	this.add(new JLabel("Taxes:"), gbc);
	gbc.gridx = 2;
	this.add(this.taxLabel, gbc);

	gbc.gridx = 2;
	this.add(new JLabel(""), gbc);

	gbc.gridx = 0;
	gbc.gridy = this.menu.size() + 3;
	this.add(new JLabel("Total:"), gbc);
	gbc.gridx = 2;
	this.add(this.totalLabel, gbc);

	gbc.gridx = 2;
	this.add(new JLabel(""), gbc);

	gbc.gridx = 0;
	gbc.gridy = this.menu.size() + 4;
	gbc.gridwidth = 3;
	gbc.fill = java.awt.GridBagConstraints.NONE;
	gbc.anchor = java.awt.GridBagConstraints.CENTER;
	gbc.insets = new java.awt.Insets(10, 0, 20, 0);
	this.printButton.setPreferredSize(new java.awt.Dimension(90, 30));
	this.add(this.printButton, gbc);
    }

    /**
     * Register the widget listeners with the widgets.
     */
    private void registerListeners() {
	// Register the PrinterListener with the print button.
	this.printButton.addActionListener(new PrintListener());

	for (JTextField quantity : this.quantityFields) {
	    quantity.addFocusListener(new QuantityListener());
	}
    }
}