package cp213;

import java.util.Scanner;

/**
 * Wraps around an Order object to ask for MenuItems and quantities.
 *
 * @author Jacob Choy
 * @author Abdul-Rahman Mawlood-Yunis
 * @author David Brown
 * @version 2024-10-15
 */
public class Cashier {

	private Menu menu = null;

	/**
	 * Constructor.
	 *
	 * @param menu A Menu.
	 */
	public Cashier(Menu menu) {
		this.menu = menu;
	}

	/**
	 * Reads keyboard input. Returns a positive quantity, or 0 if the input is not a
	 * valid positive integer.
	 *
	 * @param scan A keyboard Scanner.
	 * @return
	 */
	private int askForQuantity(Scanner scan) {
		int quantity = 0;
		System.out.print("How many do you want? ");

		try {
			String line = scan.nextLine();
			quantity = Integer.parseInt(line);
		} catch (NumberFormatException nfex) {
			System.out.println("Not a valid number");
		}
		return quantity;
	}

	/**
	 * Prints the menu.
	 */
	private void printCommands() {
		System.out.println("\nMenu:");
		System.out.println(menu.toString());
		System.out.println("Press 0 when done.");
		System.out.println("Press any other key to see the menu again.\n");
	}

	/**
	 * Asks for commands and quantities. Prints a receipt when all orders have been
	 * placed.
	 *
	 * @return the completed Order.
	 */
	public Order takeOrder() {
		Scanner in = new Scanner(System.in);
		Order order = new Order();
		boolean done = false;

		System.out.println("Welcome to WLU Foodorama! \n");
		this.printCommands();

		while (!done) {
			System.out.print("Command: ");

			if (in.hasNextInt()) {
				int input = Integer.parseInt(in.nextLine());

				if (input == 0) {
					done = true;
					System.out.println("-".repeat(40));
					System.out.println("Receipt");
					System.out.println(order);
				} else if (input > 0 && input <= this.menu.size()) {
					MenuItem item = this.menu.getItem(input - 1);
					int inputQuantity = this.askForQuantity(in);

					if (inputQuantity > 0) {
						order.add(item, inputQuantity);
					} else {
						System.out.println("Not a valid number");
					}
				} else {
					System.out.println("Not a valid number");
					this.printCommands();
				}
			} else {
				in.nextLine();
				System.out.println("Not a valid number");
				this.printCommands();
			}
		}
		return order;

	}
}